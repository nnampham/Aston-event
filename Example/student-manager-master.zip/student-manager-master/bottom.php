
<?php
}
	else {
		header('location:login.php');
}
?>